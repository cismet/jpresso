import de.cismet.jpressocore.execution.ProjectPlanBase;

public class ProjectPlan extends ProjectPlanBase {

    public void start() {
        //ADD CUSTOM CODE HERE:
        //EXAMPLE:
        //EXECUTOR.test("yourRunHere.run");
        //EXECUTOR.execute("yourRunHere.run");
        //EXECUTOR.test("yourSQLHere.rqs");
        //EXECUTOR.execute("yourSQLHere.rqs");
    }
}

